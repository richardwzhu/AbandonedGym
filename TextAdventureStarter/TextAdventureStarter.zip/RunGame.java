import textadventure.World;

public class RunGame {
	
	public static void main(String[] args) {
		
		World game = new World();		
		game.play();
		
		
	}	
}